# Recovery Controller :: Change Log

* 2020-1008: 0.0.4.1 (LisiasT) for KSP>= 1.3
	+ Added KSPe facilities for:
		- Log, UI, Instalment checks
	+ Moved the whole shebang to the `net.lisias.ksp` folder hierarchy
	+ Reworked all the merged things below to keep working from KSP 1.3 and above
* 2019-1027: 0.0.4 (linuxgurugamer) for KSP 1.8
	+ Updated for KSP 1.8
* 2019-0730: 0.0.3.8 (linuxgurugamer) for KSP 0.7.3
	+ Added InstallChecker
	+ Updated AssemblyVersion.tt
	+ Thanks to github user @Maartenvm:
		- Added support for Universal Storage Decouplers
* 2019-0124: 0.0.3.7 (linuxgurugamer) for KSP 0.7.3
	+ Changed startup option to instantly
* 2019-0122: 0.0.3.5 (linuxgurugamer) for KSP 0.7.3
	+ Fixed startup sequence for 1.5 and later
* 2019-0109: 0.0.3.4 (linuxgurugamer) for KSP 0.7.3
* 2018-1025: 0.0.3.3 (linuxgurugamer) for KSP 0.7.3
	+ Version bump for 1.5 rebuild
* 2018-0416: 0.0.3.2 (linuxgurugamer) for KSP 0.7.3
	+ Initial standalone release, updated for 1.4.1+
